#!/usr/bin/env python3
"""بعد از `npx cap add android` اجرا می‌شه و این‌ها رو اعمال می‌کنه:
  1) آیکن برنامه (از پوشهٔ resources/android)
  2) حالت افقی (sensorLandscape)
  3) تمام‌صفحه (مخفی شدن نوار وضعیت و دکمه‌های پایین) + پر کردن ناحیهٔ ناچ
  4) خرید درون‌برنامه‌ای مایکت/بازار (پلاگین native/NimaPayPlugin + AIDL + مجوزها)
"""
import json, os, re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ANDROID = ROOT / "android"
APP = ANDROID / "app" / "src" / "main"
RES = APP / "res"

if not APP.exists():
    sys.exit("پوشهٔ android پیدا نشد؛ اول `npx cap add android` رو اجرا کن.")

app_id = json.loads((ROOT / "capacitor.config.json").read_text(encoding="utf-8"))["appId"]

# ---------- 1) آیکن ----------
src = ROOT / "resources" / "android"
for d in src.glob("mipmap-*"):
    dst = RES / d.name
    dst.mkdir(parents=True, exist_ok=True)
    for f in d.glob("*.png"):
        shutil.copy(f, dst / f.name)
# رنگ پس‌زمینهٔ آیکن تطبیقی (adaptive)
(RES / "values").mkdir(parents=True, exist_ok=True)
(RES / "values" / "ic_launcher_background.xml").write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    '    <color name="ic_launcher_background">#12306E</color>\n</resources>\n',
    encoding="utf-8",
)
# ---------- 2) افقی ----------
manifest = APP / "AndroidManifest.xml"
m = manifest.read_text(encoding="utf-8")
m = re.sub(r'\s+android:screenOrientation="[^"]*"', "", m)
m = m.replace('android:name=".MainActivity"',
              'android:name=".MainActivity"\n            android:screenOrientation="sensorLandscape"', 1)
manifest.write_text(m, encoding="utf-8")

# ---------- 3) تمام‌صفحه ----------
styles = RES / "values" / "styles.xml"
if styles.exists():
    s = styles.read_text(encoding="utf-8")
    item = '<item name="android:windowFullscreen">true</item>'
    if item not in s:
        s = re.sub(r'(<style name="AppTheme\.NoActionBar(?:Launch)?"[^>]*>)',
                   r'\1\n        ' + item, s)
        styles.write_text(s, encoding="utf-8")

java_dir = APP / "java" / Path(*app_id.split("."))
java_dir.mkdir(parents=True, exist_ok=True)
NATIVE = ROOT / "native"
for tpl, out in (("MainActivity.java.tpl", "MainActivity.java"), ("NimaPayPlugin.java.tpl", "NimaPayPlugin.java")):
    (java_dir / out).write_text(
        (NATIVE / tpl).read_text(encoding="utf-8").replace("__APP_ID__", app_id), encoding="utf-8")

# ---------- 4) خرید درون‌برنامه‌ای (مایکت / بازار) ----------
STORES = {
    "myket":  dict(pkg="ir.mservices.market", action="ir.mservices.market.InAppBillingService.BIND",
                   perm="ir.mservices.market.BILLING"),
    "bazaar": dict(pkg="com.farsitel.bazaar", action="ir.cafebazaar.pardakht.InAppBillingService.BIND",
                   perm="com.farsitel.bazaar.permission.PAY_THROUGH_BAZAAR"),
}
store = (os.environ.get("STORE") or "myket").strip().lower()
if store not in STORES:
    sys.exit(f"STORE نامعتبره: {store} (myket یا bazaar)")
st = STORES[store]
# کلید عمومی RSA فروشگاه (عمومیه، مخفی نیست). با Secret به اسم STORE_PUBLIC_KEY می‌شه عوضش کرد.
DEFAULT_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDj9eSnYQxdMc92CTdl73PXemTlkT1pQZFKYUL/QHLX8cxLhEjuogu0SrEbYwM/sRLh+Ffqij8Fr0a1+EIks2uYCr4iJmtqrP13i92nxrtaSc9GVRMgvA9/Ldu5T4qDH7YSOP1OTlvOhu31NT/2Od3KoOKzjobtbaYNYPnxNNAhpQIDAQAB"
pub = (os.environ.get("STORE_PUBLIC_KEY") or DEFAULT_PUBLIC_KEY).strip()

# فایل AIDL
aidl_dir = APP / "aidl" / "com" / "android" / "vending" / "billing"
aidl_dir.mkdir(parents=True, exist_ok=True)
shutil.copy(NATIVE / "IInAppBillingService.aidl", aidl_dir / "IInAppBillingService.aidl")

# رشته‌های فروشگاه
(RES / "values" / "pay.xml").write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
    f'    <string name="pay_store_pkg" translatable="false">{st["pkg"]}</string>\n'
    f'    <string name="pay_bind_action" translatable="false">{st["action"]}</string>\n'
    f'    <string name="pay_public_key" translatable="false">{pub}</string>\n</resources>\n',
    encoding="utf-8",
)

# مجوز + queries در منیفست
m = manifest.read_text(encoding="utf-8")
if st["perm"] not in m:
    block = (f'    <uses-permission android:name="{st["perm"]}" />\n'
             f'    <queries>\n        <package android:name="{st["pkg"]}" />\n    </queries>\n\n    ')
    m = m.replace("<application", block + "<application", 1)
    manifest.write_text(m, encoding="utf-8")

# فعال کردن AIDL در gradle
gradle = ANDROID / "app" / "build.gradle"
g = gradle.read_text(encoding="utf-8")
if "aidl true" not in g and "aidl = true" not in g:
    g = re.sub(r"(?m)^android\s*\{", "android {\n    buildFeatures {\n        aidl true\n    }", g, count=1)
    gradle.write_text(g, encoding="utf-8")

print(f"OK: icon + landscape + fullscreen + billing({store}) applied")
