/* پل پرداخت: فقط داخل APK فعاله (Capacitor + پلاگین NimaPay). روی وب هیچ کاری نمی‌کنه. */
(function(){
  var C=window.Capacitor;
  if(!(C&&C.isNativePlatform&&C.isNativePlatform()))return;
  /* شناسهٔ محصول‌هایی که باید توی پنل مایکت/بازار بسازی. consume:false یعنی یک‌بار مصرف نیست (دائمی) */
  var SKU={
    coins_c10:{id:"coins_c10",consume:true},   /* بستهٔ ۱۰ هزار سکه  - ۱۵٬۰۰۰ تومان */
    coins_c20:{id:"coins_c20",consume:true},   /* بستهٔ ۲۰ هزار سکه  - ۲۵٬۰۰۰ تومان */
    coins_c35:{id:"coins_c35",consume:true},   /* بستهٔ ۳۵ هزار سکه  - ۲۹٬۰۰۰ تومان */
    vip_w:{id:"vip_w",consume:true},           /* VIP هفتگی  - ۱۵٬۰۰۰ تومان */
    vip_m:{id:"vip_m",consume:true},           /* VIP ماهانه - ۴۰٬۰۰۰ تومان */
    vip_q:{id:"vip_q",consume:true},           /* VIP سه‌ماهه - ۱۰۰٬۰۰۰ تومان */
    message:{id:"message",consume:true},       /* ارسال پیام  - ۳۰٬۰۰۰ تومان */
    takido:{id:"takido",consume:false}         /* نشان تکیدو فن - ۵٬۰۰۰ تومان (دائمی) */
  };
  function note(t){
    try{
      var d=document.createElement("div");
      d.textContent=t; d.setAttribute("dir","rtl");
      d.style.cssText="position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483647;background:#1b1f2e;color:#fff;padding:10px 18px;border-radius:12px;font:600 14px sans-serif;box-shadow:0 6px 24px #0008;max-width:80vw;text-align:center";
      document.body.appendChild(d); setTimeout(function(){d.remove()},3200);
    }catch(e){}
  }
  window.NIMA_PAY=function(o,cb){
    var m=SKU[o.item]||{id:String(o.item),consume:true}, P=C.Plugins&&C.Plugins.NimaPay;
    if(!P){note("پرداخت در دسترس نیست");cb(false);return}
    P.buy({sku:m.id,consumable:m.consume}).then(function(r){
      var ok=!!(r&&r.ok);
      try{cb(ok)}catch(e){}                       /* اول جنس تحویل بشه */
      if(ok&&m.consume&&r.token)P.consume({token:r.token}); /* بعد مصرف بشه */
    }).catch(function(e){
      note((e&&(e.message||e.errorMessage))||"پرداخت انجام نشد"); cb(false);
    });
  };
})();
