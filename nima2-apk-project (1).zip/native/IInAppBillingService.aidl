package com.android.vending.billing;

import android.os.Bundle;

// پروتکل استاندارد In-App Billing v3 (مایکت و بازار هر دو همین رو پیاده کردن).
// ترتیب متدها نباید عوض بشه.
interface IInAppBillingService {
    int isBillingSupported(int apiVersion, String packageName, String type);
    Bundle getSkuDetails(int apiVersion, String packageName, String type, in Bundle skusBundle);
    Bundle getBuyIntent(int apiVersion, String packageName, String sku, String type, String developerPayload);
    Bundle getPurchases(int apiVersion, String packageName, String type, String continuationToken);
    int consumePurchase(int apiVersion, String packageName, String purchaseToken);
}
