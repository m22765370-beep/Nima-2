1) همهٔ فایل‌ها رو تو یک ریپوی GitHub آپلود کن.
2) تب Actions > "Build APK" (دیباگ) خودکار با هر push اجرا می‌شه؛ خروجی تو Artifacts.
3) برای نسخهٔ نهایی (بازار/مایکت): یک keystore بساز:
   keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nima
   بعد base64 بگیر (base64 -w0 release.jks) و تو Settings > Secrets > Actions اینا رو بذار:
   KEYSTORE_BASE64 , KEYSTORE_PASSWORD , KEY_ALIAS , KEY_PASSWORD
   و "Build Signed Release APK" رو دستی اجرا کن.
keystore رو جایی امن نگه دار؛ برای آپدیت‌ها باید همیشه همین باشه.

---
تغییرات جدید (آیکن + افقی + تمام‌صفحه):
- آیکن برنامه از پوشهٔ resources/android گرفته می‌شه (برای عوض کردنش همین عکس‌ها رو جایگزین کن؛ resources/icon-512.png هم برای ثبت تو مایکت/بازار آماده‌ست).
- فایل scripts/patch_android.py بعد از `cap add android` خودکار اجرا می‌شه (تو هر دو workflow) و برنامه رو افقی و تمام‌صفحه می‌کنه.

---
خرید درون‌برنامه‌ای (مایکت / بازار):
- پلاگین native/NimaPayPlugin.java.tpl + native/IInAppBillingService.aidl بدون کتابخانهٔ خارجی؛ patch_android.py خودکار می‌ذارتش تو پروژهٔ اندروید.
- تو پنل توسعه‌دهندهٔ مایکت (یا بازار) این محصولات رو با «همین شناسه‌ها» بساز:
    coins_c10  (مصرفی)  ۱۵٬۰۰۰ تومان    coins_c20  (مصرفی)  ۲۵٬۰۰۰ تومان    coins_c35  (مصرفی)  ۲۹٬۰۰۰ تومان
    vip_w      (مصرفی)  ۱۵٬۰۰۰ تومان    vip_m      (مصرفی)  ۴۰٬۰۰۰ تومان    vip_q      (مصرفی)  ۱۰۰٬۰۰۰ تومان
    message    (مصرفی)  ۳۰٬۰۰۰ تومان    takido     (دائمی/غیرمصرفی)  ۵٬۰۰۰ تومان
  (اگه شناسه‌ها فرق داره، فقط جدول SKU بالای www/pay-bridge.js رو عوض کن)
- کلید عمومی RSA مایکت داخل scripts/patch_android.py گذاشته شده (برای تأیید امضای خرید). اگه عوضش کردی، Secret اختیاری STORE_PUBLIC_KEY ازش جلو می‌زنه.
- فروشگاه رو موقع اجرای دستی workflow از لیست «store» انتخاب کن (پیش‌فرض: myket).
- خرید فقط وقتی کار می‌کنه که APK رو (با امضای release) تو پنل فروشگاه آپلود کرده باشی و اپ فروشگاه رو گوشی نصب باشه.
