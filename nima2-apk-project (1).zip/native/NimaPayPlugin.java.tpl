package __APP_ID__;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Base64;

import com.android.vending.billing.IInAppBillingService;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONObject;

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;

/** پل خرید درون‌برنامه‌ای (مایکت / بازار) — بدون هیچ کتابخانهٔ خارجی. */
@CapacitorPlugin(name = "NimaPay")
public class NimaPayPlugin extends Plugin {
    static final int REQ = 7391;
    static NimaPayPlugin INSTANCE;

    private IInAppBillingService svc;
    private PluginCall pending;
    private String pendingSku;

    @Override
    public void load() { INSTANCE = this; }

    @Override
    protected void handleOnDestroy() {
        try { if (svc != null) getContext().unbindService(conn); } catch (Exception ignored) {}
        svc = null;
        INSTANCE = null;
    }

    private String res(String name) {
        Context c = getContext();
        return c.getString(c.getResources().getIdentifier(name, "string", c.getPackageName()));
    }

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            svc = IInAppBillingService.Stub.asInterface(b);
            synchronized (conn) { conn.notifyAll(); }
        }
        @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
    };

    /** اتصال به سرویس فروشگاه (روی ترد پس‌زمینه صدا بزن). */
    private boolean connect() {
        if (svc != null) return true;
        try {
            Intent i = new Intent(res("pay_bind_action"));
            i.setPackage(res("pay_store_pkg"));
            if (!getContext().bindService(i, conn, Context.BIND_AUTO_CREATE)) return false;
            synchronized (conn) { if (svc == null) conn.wait(8000); }
        } catch (Exception e) { return false; }
        return svc != null;
    }

    private void fail(PluginCall call, String msg) {
        if (call == null) return;
        call.reject(msg);
        try { getBridge().releaseCall(call); } catch (Exception ignored) {}
        if (call == pending) { pending = null; pendingSku = null; }
    }

    @PluginMethod
    public void buy(final PluginCall call) {
        final String sku = call.getString("sku");
        if (sku == null || sku.isEmpty()) { call.reject("شناسهٔ محصول خالیه"); return; }
        if (pending != null) { call.reject("یه خرید دیگه در حال انجامه"); return; }
        getBridge().saveCall(call);
        pending = call; pendingSku = sku;
        new Thread(new Runnable() { @Override public void run() {
            try {
                if (!connect()) { fail(call, "اتصال به فروشگاه برقرار نشد؛ مایکت/بازار نصب و باز باشه"); return; }
                String pkg = getContext().getPackageName();
                int sup = svc.isBillingSupported(3, pkg, "inapp");
                if (sup != 0) { fail(call, "خرید درون‌برنامه‌ای پشتیبانی نمی‌شه (کد " + sup + ")"); return; }
                Bundle b = svc.getBuyIntent(3, pkg, sku, "inapp", "nima");
                int rc = b.getInt("RESPONSE_CODE", 6);
                if (rc == 7) {
                    // قبلاً خریده‌شده و مصرف‌نشده؛ مصرفش می‌کنیم تا دوباره بشه خرید
                    if (call.getBoolean("consumable", true)) consumeOwned(sku);
                    fail(call, "خرید قبلی هنوز بسته نشده بود؛ یه بار دیگه امتحان کن"); return;
                }
                if (rc != 0) { fail(call, rc == 1 ? "خرید لغو شد" : "خطا در شروع خرید (کد " + rc + ")"); return; }
                final PendingIntent pi = b.getParcelable("BUY_INTENT");
                if (pi == null) { fail(call, "خطا در باز کردن صفحهٔ پرداخت"); return; }
                getActivity().runOnUiThread(new Runnable() { @Override public void run() {
                    try {
                        getActivity().startIntentSenderForResult(pi.getIntentSender(), REQ, new Intent(), 0, 0, 0);
                    } catch (Exception e) { fail(call, "صفحهٔ پرداخت باز نشد"); }
                }});
            } catch (Exception e) { fail(call, "خطا: " + e.getMessage()); }
        }}).start();
    }

    /** از MainActivity.onActivityResult صدا زده می‌شه. */
    boolean handleResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ) return false;
        PluginCall call = pending; String sku = pendingSku;
        if (call == null) return true;
        if (data == null) { fail(call, "پرداخت انجام نشد"); return true; }
        int rc = data.getIntExtra("RESPONSE_CODE", 6);
        String pd = data.getStringExtra("INAPP_PURCHASE_DATA");
        String sig = data.getStringExtra("INAPP_DATA_SIGNATURE");
        if (resultCode != Activity.RESULT_OK || rc != 0 || pd == null) {
            fail(call, rc == 1 || resultCode == Activity.RESULT_CANCELED ? "خرید لغو شد" : "پرداخت انجام نشد (کد " + rc + ")");
            return true;
        }
        try {
            JSONObject o = new JSONObject(pd);
            if (!sku.equals(o.optString("productId")) || o.optInt("purchaseState", 0) != 0) {
                fail(call, "اطلاعات خرید نامعتبره"); return true;
            }
            String key = res("pay_public_key").trim();
            if (!key.isEmpty() && !verify(key, pd, sig)) { fail(call, "امضای خرید تأیید نشد"); return true; }
            JSObject r = new JSObject();
            r.put("ok", true); r.put("sku", sku); r.put("token", o.optString("purchaseToken"));
            call.resolve(r);
            try { getBridge().releaseCall(call); } catch (Exception ignored) {}
            pending = null; pendingSku = null;
        } catch (Exception e) { fail(call, "خطا در پردازش خرید"); }
        return true;
    }

    /** بعد از اینکه بازی جنس رو تحویل داد، JS این رو صدا می‌زنه. */
    @PluginMethod
    public void consume(final PluginCall call) {
        final String token = call.getString("token");
        if (token == null) { call.resolve(); return; }
        new Thread(new Runnable() { @Override public void run() {
            try {
                if (connect()) svc.consumePurchase(3, getContext().getPackageName(), token);
            } catch (Exception ignored) {}
            call.resolve();
        }}).start();
    }

    private void consumeOwned(String sku) {
        try {
            String pkg = getContext().getPackageName();
            Bundle b = svc.getPurchases(3, pkg, "inapp", null);
            if (b.getInt("RESPONSE_CODE", 6) != 0) return;
            ArrayList<String> data = b.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
            if (data == null) return;
            for (String d : data) {
                JSONObject o = new JSONObject(d);
                if (sku.equals(o.optString("productId"))) svc.consumePurchase(3, pkg, o.optString("purchaseToken"));
            }
        } catch (Exception ignored) {}
    }

    private static boolean verify(String base64Key, String data, String sig) {
        try {
            PublicKey pk = KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(Base64.decode(base64Key, Base64.DEFAULT)));
            Signature s = Signature.getInstance("SHA1withRSA");
            s.initVerify(pk); s.update(data.getBytes("UTF-8"));
            return sig != null && s.verify(Base64.decode(sig, Base64.DEFAULT));
        } catch (Exception e) { return false; }
    }
}
